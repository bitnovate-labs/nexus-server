import express from "express";
import { ApolloServer } from "apollo-server-express";
import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from "dotenv";
import { graphqlUploadExpress } from "graphql-upload-minimal";
import { typeDefs } from "./schema/index.js";
import { resolvers } from "./resolvers/index.js";
import { db } from "./db.js";
import { authMiddleware } from "./middleware/auth.js";
//---------
import { createClient } from "@supabase/supabase-js";

const PORT = process.env.PORT || 4000;

dotenv.config();

const app = express();

// CORS Configuration
app.use(
  cors({
    origin: "http://localhost:5173", // Vite dev server
    // origin: process.env.CLIENT_URL,
    credentials: true,
  })
);

app.use(cookieParser());
app.use(authMiddleware);

// File upload middleware - must be before Apollo Server middleware
app.use(graphqlUploadExpress());

const server = new ApolloServer({
  typeDefs,
  resolvers,
  context: ({ req, res }) => ({
    req,
    res,
    db,
  }),
  cors: false, // Disable Apollo Server's CORS as we're handling it with Express
});

// Initialize Supabase client
const supabaseUrl = process.env.VITE_SUPABASE_URL; // Replace with your Supabase URL
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY; // Replace with your Supabase API key
const supabase = createClient(supabaseUrl, supabaseKey);

// Route to interact with Supabase
app.get("/users", async (req, res) => {
  // Query data from Supabase
  const { data, error } = await supabase
    .from("users") // Replace with your table name
    .select("*");

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  res.json(data);
});

await server.start();

server.applyMiddleware({
  app,
  cors: false,
  path: "/graphql",
});

app.listen(PORT, "0.0.0.0", () =>
  console.log(`🚀 Server ready on port ${PORT}`)
);
